const Product = require("../model/Product");

const addProduct = async (req, res) => {
  try {
    const { productName, productDescription, productAmount } = req.body;
    const product = new Product({
      name: productName,
      description: productDescription,
      amount: productAmount,
      userId: req.user._id,
    });

    await product.save();
    res.json({ status: "success" });
  } catch (error) {
    console.error("Error adding product:", error);
    res.status(500).json({ status: "error" });
  }
};

const getProducts = async (req, res) => {
  try {
    const userId = req.user._id; // Assuming user ID is available in req.user
    const products = await Product.find({ userId });
    res.json({ products, status: "success" });
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ status: "error" });
  }
};

const getProductById = async (req, res) => {
  try {
    const { productId } = req.params;
    const userId = req.user._id;

    const product = await Product.findById(productId);

    if (!product) {
      return res.status(404).json({ status: "error", message: "Product not found" });
    }

    res.json({ product, status: "success" });
  } catch (error) {
    console.error("Error fetching product details:", error);
    res.status(500).json({ status: "error", message: "Error fetching product details" });
  }
};

const updateProduct = async (req, res) => {
  try {
    const { productId } = req.params;
    const userId = req.user._id;

    const product = await Product.findOne({ _id: productId, userId });

    if (!product) {
      return res.status(404).json({ status: "error", message: "Product not found" });
    }
    product.name = req.body.productName;
    product.description = req.body.productDescription;
    product.amount = req.body.productAmount;

    await product.save();

    res.json({ status: "success", message: "Product updated" });
  } catch (error) {
    console.error("Error updating product:", error);
    res.status(500).json({ status: "error", message: "Error updating product" });
  }
};

const deleteProduct = async (req, res) => {
  try {
    const { productId } = req.params;
    const product = await Product.findOne({
      _id: productId,
      userId: req.user._id,
    });

    if (!product) {
      return res.status(404).json({ status: "error", message: "Product not found" });
    }

    await product.remove();
    res.json({ status: "success", message: "Product deleted" });
  } catch (error) {
    console.error("Error deleting product:", error);
    res.status(500).json({ status: "error", message: "Error deleting product" });
  }
};

module.exports = {
  addProduct,
  getProducts,
  getProductById, // Export getProductById function
  updateProduct,
  deleteProduct,
};
