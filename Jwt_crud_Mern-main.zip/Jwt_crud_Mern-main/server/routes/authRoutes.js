const { register, login } = require("../controllers/authControllers");
const { checkUser } = require("../middlewares/authMiddleware");

const router = require("express").Router();

router.post("/", checkUser);
router.post("/register", register);
router.post("/login", login);

router.post("/verify", checkUser, (req, res) => {
    // User is verified, return user's data including email
    res.json({ status: true, user: req.user.email }); // Include the email in the response
  });

module.exports = router;
