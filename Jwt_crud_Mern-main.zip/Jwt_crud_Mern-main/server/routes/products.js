const express = require("express");
const router = express.Router();
const { checkUser } = require("../middlewares/authMiddleware");
const {
  addProduct,
  getProducts,
  updateProduct,
  deleteProduct,
  getProductById,
} = require("../controllers/productController");

router.get("/", checkUser, getProducts);
router.post("/add", checkUser, addProduct);
router.get("/:productId", checkUser, getProductById);
router.put("/:productId", checkUser, updateProduct);
router.delete("/:productId", checkUser, deleteProduct);

module.exports = router