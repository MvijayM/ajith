const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Product name is required"],
  },
  description: {
    type: String,
    required: [true, "Product description is required"],
  },
  amount: {
    type: Number,
    required: [true, "Product amount is required"],
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User", // Reference to the User model for associating products with users
    required: true,
  },
});

const Product = mongoose.model("Product", productSchema);

module.exports = Product;
