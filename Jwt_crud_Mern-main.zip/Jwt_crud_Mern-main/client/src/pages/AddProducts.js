import React, { useState } from "react";
import axios from "axios";
import { useCookies } from "react-cookie";
import { toast, ToastContainer } from "react-toastify";
import "./AddProduct.css";
import { useNavigate } from "react-router";

export default function AddProduct() {
  const [productName, setProductName] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [productAmount, setProductAmount] = useState("");
  const [cookies] = useCookies(["jwt"]);

const navigate=useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      jwt: cookies.jwt,
      productName,
      productDescription,
      productAmount,
    };

    try {
      const response = await axios.post("http://localhost:4000/api/products/add", payload, {
        withCredentials: true,
      });
      
      if (response.data.status === "success") {

        setProductName("");
        setProductDescription("");
        setProductAmount("");
        toast.success("Product added successfully!");

        setTimeout(() => {
          navigate("/")

        }, 1000);

        console.log(response.data.status);
        
      } else {
        toast.error("Failed to add the product. Please try again.");
      }
    } catch (error) {
      console.error("Error adding product:", error);
      toast.error("An error occurred. Please try again later.");
    }
  }

  return (
    <div>
      <ToastContainer></ToastContainer>
      <h2>Add Product</h2>
      <form className="form-container" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="productName">Product Name</label>
          <input
            type="text"
            id="productName"
            className="form-control"
            value={productName}
            onChange={e => setProductName(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="productDescription">Product Description</label>
          <input
            type="text"
            id="productDescription"
            className="form-control"
            value={productDescription}
            onChange={e => setProductDescription(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="productAmount">Product Amount</label>
          <input
            type="number"
            id="productAmount"
            className="form-control"
            value={productAmount}
            onChange={e => setProductAmount(e.target.value)}
          />
        </div>

        <button type="submit" className="btn btn-primary">
          Add Product
        </button>
      </form>
    </div>
  );
}
