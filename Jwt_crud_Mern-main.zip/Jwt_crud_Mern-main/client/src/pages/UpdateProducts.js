import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { useCookies } from "react-cookie";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const UpdateProduct = () => {
  const navigate = useNavigate();
  const { productId } = useParams();
  const [cookies] = useCookies(["jwt"]);

  const [productName, setProductName] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [productAmount, setProductAmount] = useState("");

  useEffect(() => {
    axios
      .get(`http://localhost:4000/api/products/${productId}`, {
        withCredentials: true,
      })
      .then((response) => {
        const product = response.data.product;
        if (product) {
          setProductName(product.name || "");
          setProductDescription(product.description || "");
          setProductAmount(product.amount || "");
        } else {
          console.error("Product data is undefined.");
        }
      })
      .catch((error) => {
        console.error("Error fetching product details:", error);
      });
  }, [productId]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const payload = {
      jwt: cookies.jwt,
    };

    axios
      .put(
        `http://localhost:4000/api/products/${productId}`,
        {
          productName,
          productDescription,
          productAmount,
        },
        {
          withCredentials: true,
        }
      )
      .then((response) => {
        if (response.data.status === "success") {
          console.log(response.data.status,"Updated successfully");
          

          setTimeout(() => {
            navigate("/");
          }, 1000);
          toast.success("Product updated successfully!", {
            position: "top-center",
            autoClose: 3000, 
          });
          
        } else {
          console.error("Error updating product:", response.data.message);
          toast.error("Error updating product: " + response.data.message, {
            position: "top-center",
            autoClose: 3000,
          });
        }
      })
      .catch((error) => {
        console.error("Error updating product:", error);
        // Display an error toast notification for network errors
        toast.error("Network error occurred. Please try again later.", {
          position: "top-center",
          autoClose: 3000,
        });
      });
  };

  return (
    <div>
      <ToastContainer/>
      <h2>Update Product</h2>
      <form className="form-container" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="productName">Product Name</label>
          <input
            type="text"
            id="productName"
            className="form-control"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
          />
        </div>
  
        <div className="form-group">
          <label htmlFor="productDescription">Product Description</label>
          <input
            type="text"
            id="productDescription"
            className="form-control"
            value={productDescription}
            onChange={(e) => setProductDescription(e.target.value)}
          />
        </div>
  
        <div className="form-group">
          <label htmlFor="productAmount">Product Amount</label>
          <input
            type="number"
            id="productAmount"
            className="form-control"
            value={productAmount}
            onChange={(e) => setProductAmount(e.target.value)}
          />
        </div>
  
        <button type="submit" className="btn btn-primary">
          Update Product
        </button>
      </form>
    </div>
  );
  }

export default UpdateProduct;
