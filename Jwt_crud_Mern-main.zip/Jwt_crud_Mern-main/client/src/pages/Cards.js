import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useCookies } from "react-cookie";
import axios from "axios";
import "./Cards.css";
import { toast, ToastContainer } from "react-toastify";

export default function Cards() {
  const navigate = useNavigate();
  const [cookies, , removeCookie] = useCookies([]);
  const [userData, setUserData] = useState(null);
  const [product, setProduct] = useState([]);

  useEffect(() => {
    const verifyUser = async () => {
      if (!cookies.jwt) {
        navigate("/login");
      } else {
        try {
          const { data } = await axios.post(
            "http://localhost:4000/verify",
            {},
            {
              withCredentials: true,
            }
          );

          if (!data.status) {
            removeCookie("jwt");
            navigate("/login");
          } else {
            setUserData(data.user);
           
          }
        } catch (error) {
          console.error("Error verifying user:", error);
        }
      }
    };

    verifyUser();

    const fetchProducts = async () => {
      try {
        const response = await axios.get("http://localhost:4000/api/products", {
          withCredentials: true,
        });
    
        setProduct(response.data.products);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    fetchProducts();
  }, [cookies, navigate, removeCookie]);

  const logOut = () => {
    removeCookie("jwt");
    navigate("/login");
  };

  const handleDelete = async (productId) => {
    try {
      const response = await axios.delete(`http://localhost:4000/api/products/${productId}`, {
        withCredentials: true,
      });
  
      if (response.data.status === "success") {
        const updatedProducts = product.filter((p) => p._id !== productId);
        setProduct(updatedProducts);
  
        toast("Product deleted successfully", {
          theme: "dark",
        });
        console.log("Product deleted successfully");
        
      } else {
        toast("Error deleting product", {
          theme: "dark",
        });
      }
    } catch (error) {
      console.error("Error deleting product:", error);
      toast("Error deleting product", {
        theme: "dark",
      });
    }
  };
  

  return (
    <>
      <div className="private">
        {userData ? <h6>Welcome {userData}</h6> : null}
        <button onClick={logOut}>Log out</button>
      </div>

      <ToastContainer />
      <br />
      <br />
      <Link to="/addproducts" className="btn btn-success">
        ADD PRODUCTS
      </Link>

  <table className="table table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Product Name</th>
      <th>Product Description</th>
      <th>Product Amount</th>
      <th>Update</th>
      <th>Delete</th>
    </tr>
  </thead>
  <tbody>
    {product.length === 0 ? ( 
      <tr>
        <td colSpan="6">No products available</td>
      </tr>
    ) : (
      product.map((product) => (
        <tr key={product._id}>
          <td>{product._id}</td>
          <td>{product.name}</td>
          <td>{product.description}</td>
          <td>{product.amount}</td>
          <td>
            <Link to={`/updateproducts/${product._id}`} className="btn btn-primary">
              UPDATE
            </Link>
          </td>
          <td>
            <button
              className="btn btn-danger"
              onClick={() => handleDelete(product._id)}
            >
              DELETE
            </button>
          </td>
        </tr>
      ))
    )}
  </tbody>
</table>

    </>
  );
}
